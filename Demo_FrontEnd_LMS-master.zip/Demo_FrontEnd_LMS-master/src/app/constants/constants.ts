export const constants = {
    RAZOR_PAY_KEY: 'rzp_test_6n41NtIZLO0jf5',
    // RAZOR_PAY_KEY: 'rzp_test_9N1bG3mt6HgJYi',
    CURRENCY: 'INR',
    RAZORPAY_INPUT_NAME: 'Digial Lync LMS',
    RAZORPAY_INPUT_DESCRIPTION: 'Elearning Platform'
}