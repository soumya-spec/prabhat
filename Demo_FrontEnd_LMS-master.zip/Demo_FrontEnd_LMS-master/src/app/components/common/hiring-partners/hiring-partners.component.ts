import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dl-hiring-partners',
  templateUrl: './hiring-partners.component.html',
  styleUrls: ['./hiring-partners.component.scss']
})
export class HiringPartnersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
