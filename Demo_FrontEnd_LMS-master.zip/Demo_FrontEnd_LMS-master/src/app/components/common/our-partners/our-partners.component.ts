import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dl-our-partners',
  templateUrl: './our-partners.component.html',
  styleUrls: ['./our-partners.component.scss']
})
export class OurPartnersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
