export const environment = {
  production: true,
  // apiUrl: 'https://lms-api.osacad.com'
  apiUrl: 'https://dev-backend.konamars.com'
};
