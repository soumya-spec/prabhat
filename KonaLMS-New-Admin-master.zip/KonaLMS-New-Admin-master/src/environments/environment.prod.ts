export const environment = {
  production: true,
  apiUrl: 'https://lms-api.digital-lync.com'
};
