import env from './config';
import App from './app'

const app: App = new App(3002);

app.listen();