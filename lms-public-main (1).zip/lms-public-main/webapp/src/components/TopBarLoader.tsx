function TopBarLoader() {
  return null;
}

export default TopBarLoader;
