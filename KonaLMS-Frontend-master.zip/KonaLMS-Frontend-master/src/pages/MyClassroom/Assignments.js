import React from 'react'
import Assignmenttab from './Assignmenttab'

const Assignments = (props) => {
    return (
        <div>
           
          

            <h5 className="pt-3">Dead Line :</h5>
            <div>
                <h1 className="text-bold">No Resources found</h1>
                {/* <Assignmenttab /> */}
            </div>

            <br></br>
        </div>
    )
}
export default Assignments